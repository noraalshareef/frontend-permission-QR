//
//  showControllerViewController.swift
//  TravelPermitScanner
//
//  Created by Hassan Alkaff on 23/04/2020.
//  Copyright © 2020 ArwaA. All rights reserved.
//

import UIKit

class showControllerViewController: UIViewController {
    
    @IBOutlet weak var backB: UIButton!
    var data: String!

    @IBOutlet weak var myLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myLabel.text = data
  /*      var reasonsNum = data.characters.filter { $0 == "|" }.count
        myLabel.text = "Nation ID: \(String(data.prefix(10)))\n"
        myLabel.text = myLabel.text ?? <#default value#> + String(data.suffix(11))*/
        
       

        // Do any additional setup after loading the view.
    }
    

    @IBAction func backPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
