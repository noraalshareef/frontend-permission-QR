
//
//  ViewController.swift
//  TravelPermitScanner
//
//  Created by ArwaA on 29/08/1441 AH.
//  Copyright © 1441 ArwaA. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    
    
    @IBOutlet weak var videoPreview: UIView!
   // var c = false
    
    var stringURL = String()
    let avCaptureSession = AVCaptureSession()
    
    enum error : Error {
        case noCameraAvailable
        case videoInputInitFail
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        do{
            try scanQRCode()
        }
        catch
        {
            print("Failed to scan QR code!")
        }
      
    }

   func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        
        if metadataObjects != nil && metadataObjects.count > 0
        {
            var machineREadableCode = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
            if machineREadableCode.type == AVMetadataObject.ObjectType.qr
            {
                
                stringURL = machineREadableCode.stringValue!
               
               // if  showAlert(title: "QR Code", message: stringURL){
                 
                        self.performSegue(withIdentifier: "toShow", sender: self)
                  //  }
                }
                
            }
        }
    
    
  /*  func showAlert (title: String, message: String) -> Bool {
        
    let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Show", style: .default, handler:  { (action) in
            alertController.dismiss(animated: true,  completion: nil)
            self.c = true
           
             }
        
    ))

    alertController.addAction(UIAlertAction(title: "Dismiss", style: .default, handler:  { (action) in
        alertController.dismiss(animated: true,  completion:  nil )
        self.c = false
        }))
    self.present(alertController, animated: true, completion: nil)
        return true
    }
    */
    func scanQRCode() throws {
        
        guard let avCaptureDevice = AVCaptureDevice.default(for: AVMediaType.video) else {
            print("no camera !")
            throw error.noCameraAvailable
        }
        
        guard  let avCaptureInput = try? AVCaptureDeviceInput (device: avCaptureDevice )else {
            print("Failed to init. camera")
            throw error.videoInputInitFail
        }
        
        let avCaptureMetadataOutput = AVCaptureMetadataOutput()
        avCaptureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        avCaptureSession.addInput(avCaptureInput)
        avCaptureSession.addOutput(avCaptureMetadataOutput)
        
        avCaptureMetadataOutput.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        
        let avCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: avCaptureSession)
        avCaptureVideoPreviewLayer.videoGravity=AVLayerVideoGravity.resizeAspectFill
        avCaptureVideoPreviewLayer.frame = videoPreview.bounds
        self.videoPreview.layer.addSublayer(avCaptureVideoPreviewLayer)
        avCaptureSession.startRunning()
        
        
    }
    
    // do func prepare
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "toShow")
        {
        let next = segue.destination as! showControllerViewController
        next.data = stringURL
            
        }
    }

}

