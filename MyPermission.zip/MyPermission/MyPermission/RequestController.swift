//
//  RequestController.swift
//  MyPermission
//
//  Created by ArwaA on 27/08/1441 AH.
//  Copyright © 1441 ArwaA. All rights reserved.
//

import UIKit

class RequestController: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource, UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    @IBOutlet weak var backB: UIButton!
    

     var loggedID: String!
    
     var pType: String = "once"
    
    
    let progress = Progress(totalUnitCount: 10)
    
    @IBOutlet weak var onceView: UIView!
    
    @IBOutlet weak var alwaysView: UIView!
    
    var resPicker1 = UIPickerView()
    
    var pickerData1 = ["Appointment","Judgment hearing","other"]
    
    
    
    @IBOutlet weak var reasonsField1: UITextField!
    
    var resPicker2 = UIPickerView()
    var pickerData2 = ["Hospital work","Dielivery","other"]
    
    
    @IBOutlet weak var reasonsField2: UITextField!
    
    var date = UIDatePicker()
    var time = UIDatePicker()
    
    @IBOutlet weak var dateField: UITextField!
    @IBOutlet weak var timeField: UITextField!
    var startDate = UIDatePicker()
    var endDate = UIDatePicker()
    
    @IBOutlet weak var startDField: UITextField!
    
    @IBOutlet weak var endDField: UITextField!
    // outlet textfield attatcment
    
    @IBOutlet weak var destField: UITextField!
    @IBOutlet weak var submit: UIButton!
    
    
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var progressLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("arwa \(loggedID)")
        //var type = false
                
        progressBar.transform = progressBar.transform.scaledBy(x: 1, y: 5)
        
        //onceView.isHidden = false
        reasonsField1.isEnabled = true
        dateField.isEnabled = true
        timeField.isEnabled = true
        reasonsField2.isEnabled = false
        startDField.isEnabled = false
        endDField.isEnabled = false
      //  alwaysView.isHidden = true
       
        resPicker1.delegate = self
        resPicker1.dataSource = self
        reasonsField1.inputView=resPicker1
        
        createDatePicker()
        createTimePicker()
        
        resPicker2.delegate = self
        resPicker2.dataSource = self
        reasonsField2.inputView=resPicker2
        
        
        
        
        createStartDPicker()
        createEndDPicker()
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func Switch(_ sender: UISwitch) {
        
        if(sender.isOn)
        {
         // onceView.isHidden = true
        //  alwaysView.isHidden = false
            reasonsField1.isEnabled = false
            dateField.isEnabled = false
            timeField.isEnabled = false
            
            reasonsField1.placeholder = "choose reason"
            dateField.placeholder = "choose date"
            timeField.placeholder = "choose time"
            reasonsField2.isEnabled = true
            startDField.isEnabled = true
            endDField.isEnabled = true
            pType = "always"
        }
        else{
         // onceView.isHidden = false
           // alwaysView.isHidden = true
            reasonsField1.isEnabled = true
            dateField.isEnabled = true
            timeField.isEnabled = true
            reasonsField2.isEnabled = false
            reasonsField2.placeholder = "choose reason"
           
            startDField.isEnabled = false
            startDField.placeholder = "choose date"
            
            endDField.isEnabled = false
            endDField.placeholder = "choose date"
            
            pType = "once"
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        var countrows : Int = pickerData1.count
        if pickerView == resPicker2 {
            countrows = self.pickerData2.count
        }
        
        return countrows
    }
    
    
    // The data to return for the row and component (column) that's being passed in
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == resPicker1 {
            let titleRow = pickerData1[row]
            return titleRow
        } else if pickerView == resPicker2 {
            let titleRow = pickerData2[row]
            return titleRow
        }
        
        return ""
    }

    

 func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
    
    if (pickerView == resPicker1 )
    {
        reasonsField1.text=pickerData1[row]
        reasonsField1.resignFirstResponder()
    }
    else
    {
        reasonsField2.text=pickerData2[row]
        reasonsField2.resignFirstResponder()
    }
 
 }
    
    
    
    //date picker
    
    func createDatePicker()
    {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let done = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([done], animated: false)
        dateField.inputAccessoryView = toolbar
        dateField.inputView=date
        date.datePickerMode = .date
    }
    
  
    @objc func donePressed()
    {
       let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        let dateString = formatter.string(from: date.date)
        dateField.text="\(dateString)"
        
        self.view.endEditing(true)
    }
    
    func createTimePicker()
      {
          let toolbar = UIToolbar()
          toolbar.sizeToFit()
          
          let done = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(done1Pressed))
          toolbar.setItems([done], animated: false)
          timeField.inputAccessoryView = toolbar
          timeField.inputView=time
          time.datePickerMode = .time
      }
      
    
      @objc func done1Pressed()
      {
       let formatter = DateFormatter()
       formatter.dateStyle = .none
        formatter.timeStyle = .medium
        formatter.locale = Locale(identifier: "en_SA")
        //formatter.timeZone = NSTimeZone(abbreviation: "GMT") as TimeZone!
        time.date.addingTimeInterval(TimeInterval(NSTimeZone.local.secondsFromGMT()))
        let timeString = formatter.string(from: time.date)
       timeField.text="\(timeString)"
       self.view.endEditing(true)
        
      }
    
    
    func  createStartDPicker()  {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let done = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(startDonePressed))
        toolbar.setItems([done], animated: false)
        startDField.inputAccessoryView = toolbar
        startDField.inputView=startDate
        startDate.datePickerMode = .date
    }
    
    @objc func startDonePressed()
    {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        let dateString = formatter.string(from: (startDate.date))
        startDField.text="\(dateString)"
        self.view.endEditing(true)
    }
  
    func  createEndDPicker()  {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let done = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(endDonePressed))
        toolbar.setItems([done], animated: false)
        endDField.inputAccessoryView = toolbar
        endDField.inputView=endDate
        endDate.datePickerMode = .date
    }
    
    @objc func endDonePressed()
    {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        let dateString = formatter.string(from: (endDate.date))
        endDField.text="\(dateString)"
        self.view.endEditing(true)
    }
    
    var IMGView = UIImageView()
    
    @IBAction func uploadIMG(_ sender: Any) {
        
        let imgPickerController = UIImagePickerController()
        imgPickerController.delegate = self
        
        let actionSheet = UIAlertController (title: "photo source", message: "choose source", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction (title: "Camera", style: .default, handler: {(action: UIAlertAction) in
            imgPickerController.sourceType = .camera
            self.present(imgPickerController, animated: true , completion: nil)}))
        
        actionSheet.addAction(UIAlertAction (title: "Photo Library", style: .default, handler: {(action: UIAlertAction) in
            imgPickerController.sourceType = .photoLibrary
            self.present(imgPickerController, animated: true , completion: nil)}))
        
        actionSheet.addAction(UIAlertAction (title: "Cancel", style: .cancel, handler: nil ))
            
        self.present(actionSheet, animated: true , completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        
       // code for progress bar & its label
        
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true){ (timer) in
            guard self.progress.isFinished == false else{
                timer.invalidate()
                print("finish")
                return
            }
            self.progress.completedUnitCount += 1
            let progressFloat = Float(self.progress.fractionCompleted)
           // var c :Int = Int(progressFloat*100)
            print(progressFloat)
            let formatter = NumberFormatter()
            formatter.numberStyle = .percent
            self.progressLabel.text =  formatter.string(for: progressFloat*1)
            print(progressFloat*10)
            self.progressBar.setProgress(progressFloat, animated: true)
        }
       
       
        
            
       
        picker.dismiss(animated: true, completion: nil)
        
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func backPressed(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func submitPressed(_ sender: Any) {
        var pram: [String:String]
        
        if(pType == "once")
        {
            if(reasonsField1.text == "" || dateField.text == "" || timeField.text == "")
            {
                 let action = UIAlertController (title: "Missing Data", message: "Please fill all fields", preferredStyle: .alert)
                action.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                
                self.present(action, animated: true, completion: nil)
            }
            else {
                //send
                let id = loggedID
                //var type = false
                let reason = reasonsField1.text
                let date1 = dateField.text
                let date2 = timeField.text
                let place = destField.text
                
                pram = ["id":"\(id )  ", "isPermanent":"false", "reason":"\(reason ?? "Other")", "date1":"\(date1 ?? "22 april 20") " , "date2":"\(date2 ?? "22 may 20")", "place":"\(place ?? "school")", "attached":"value"]
                print(pram)
                
                data_send(pram,url: "https://beee.azurewebsites.net/rest/service/setUserData?")
            }
        }else{
            if(reasonsField2.text == "" || startDField.text == "" || endDField.text == "")
                       {
                        let action = UIAlertController (title: "Missing Data", message: "Please fill all fields", preferredStyle: .alert)
                                      action.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                        
                         self.present(action, animated: true, completion: nil)
                       }
                       else {
                           //send
                
                let id = loggedID
                //var type = false
                let reason = reasonsField2.text
                let date1 = startDField.text
                let date2 = endDField.text
                let place = destField.text
                
                pram = ["id":"\(id )",  "isPermanent":"true", "reason":"\(reason ?? "Other")"  ,"date1":"\(date1 ?? " 22 april 20")" ,"date2":"\(date2 ?? "22 may 20")" ,"place":"\(place ?? "anywhere")" ,"attached":"value"]
                
                print(pram)
                               
                data_send(pram,url: "https://beee.azurewebsites.net/rest/service/setUserData?")
                       }
        }
    }
    
    func data_send(_ pram:[String : String] , url:String)
    {
        guard let url = URL(string: url) else { return }
        
       
        do {
            let httpBody = try? JSONSerialization.data(withJSONObject: pram, options: [])
       
            var request = URLRequest(url: url as URL)
            request.httpMethod = "POST"
            request.httpBody = httpBody
            request.setValue(" application/json", forHTTPHeaderField:"Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
       
        // the upload task, uploadJob, is defined here
        
            let session = URLSession.shared
                session.dataTask(with: request) { (data, response, error) in
            
                        if error != nil {
                            
        // display an alert if there is an error inside the DispatchQueue.main.async

                            DispatchQueue.main.async
                            {
                                    let alert = UIAlertController(title: "can't complete the request", message: "Do you have Internet access?", preferredStyle: .alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                            }
                        }
                        else
                        {
                            if let unwrappedData = data {
                                
                                let returnedData = NSString(data: unwrappedData, encoding: String.Encoding.utf8.rawValue) // Response from web server hosting the database
                               
                                if returnedData == "responcetrue" // insert into database worked
                                {

        // display an alert if no error and database insert worked (return = 1) inside the DispatchQueue.main.async

                                    DispatchQueue.main.async
                                    {
                                        let alert = UIAlertController(title: "Done successfully", message: "Your application sent successfully", preferredStyle: .alert)
                                        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                    }
                                }
                                else
                                {
        // display an alert if an error and database insert didn't worked (return != 1) inside the DispatchQueue.main.async

                                    DispatchQueue.main.async
                                    {

                                    let alert = UIAlertController(title: "Upload Didn't Work", message: "Looks like the insert into the database did not worked.", preferredStyle: .alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                    }
                                }
                            }
                }
            }.resume()
                    
                }
            }

}
   
