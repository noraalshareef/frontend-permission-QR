//
//  HomeController.swift
//  MyPermission
//
//  Created by ArwaA on 27/08/1441 AH.
//  Copyright © 1441 ArwaA. All rights reserved.
//

import UIKit

class HomeController: UIViewController {
    
    @IBOutlet weak var welcomeID: UILabel!
    var loggedID: String!

    override func viewDidLoad() {
        super.viewDidLoad()

        welcomeID.text = "Hello \(loggedID!)"
        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var requestB: UIButton!
    
    
    @IBOutlet weak var obtainB: UIButton!
    
    @IBAction func requestPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "request", sender: self)
    }
    
     func prepare(for segue: UIStoryboardSegue, sender: UIButton) {
        if (sender == requestB)
        {
        let nextViewController = segue.destination as! RequestController
            nextViewController.loggedID = self.loggedID
        }
        else
        {
        let nextViewController = segue.destination as! ObtainController
            nextViewController.loggedID = loggedID
    }
    }
    
    @IBAction func obtainPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "obtain", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
