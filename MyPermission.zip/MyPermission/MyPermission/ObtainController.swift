//
//  ObtainController.swift
//  MyPermission
//
//  Created by ArwaA on 28/08/1441 AH.
//  Copyright © 1441 ArwaA. All rights reserved.
//

import UIKit

class ObtainController: UIViewController {

     var loggedID: String!
    
    @IBOutlet weak var qrImageView: UIImageView!
    
    @IBOutlet weak var generateButton: UIButton!
    
    
    @IBOutlet weak var saveButton: UIButton!
    
   
    @IBOutlet weak var backButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        saveButton.isEnabled = false;
    }
    
   
    @IBAction func buttonGenerator(_ sender: Any) {
       /*
        let urls = "https://beee.azurewebsites.net/rest/service/getUserData?"
        let url:NSURL = NSURL(string: urls)!
        var request = URLRequest(url: url as URL)
        var pram = "id=\(loggedID)"
        request.httpMethod = "POST"
        let dataD = pram.data(using: .utf8)
        
        
        do
                       {
                       
               // the upload task, uploadJob, is defined here

                           let uploadJob = URLSession.shared.uploadTask(with: request, from: dataD)
                           {
                               data, response, error in
                               
                               if error != nil {
                                   
               // display an alert if there is an error inside the DispatchQueue.main.async

                                   DispatchQueue.main.async
                                   {
                                           let alert = UIAlertController(title: "Upload Didn't Work?", message: "Looks like the connection to the server didn't work.  Do you have Internet access?", preferredStyle: .alert)
                                           alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                           self.present(alert, animated: true, completion: nil)
                                   }
                               }
                               else
                               {
                                   if let unwrappedData = data {
                                       
                                       let returnedData = NSString(data: unwrappedData, encoding: String.Encoding.utf8.rawValue) // Response from web server hosting the database
                                       print(returnedData)
                                       if returnedData == "true" // insert into database worked
                                       {

               // display an alert if no error and database insert worked (return = 1) inside the DispatchQueue.main.async

                                           DispatchQueue.main.async
                                           {
                                               let alert = UIAlertController(title: "Upload OK?", message: "Looks like the upload and insert into the database worked.", preferredStyle: .alert)
                                               alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                               self.present(alert, animated: true, completion: nil)
                                           }
                                       }
                                       else
                                       {
               // display an alert if an error and database insert didn't worked (return != 1) inside the DispatchQueue.main.async

                                           DispatchQueue.main.async
                                           {

                                           let alert = UIAlertController(title: "Upload Didn't Work", message: "Looks like the insert into the database did not worked.", preferredStyle: .alert)
                                           alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                           self.present(alert, animated: true, completion: nil)
                                           }
                                       }
                                   }
                               }
                           }
                           uploadJob.resume()
                       }
        
        */
      //  var id = "1023456789"
        var pram = ["id":"\(loggedID)"]
        
        guard let url = URL(string: "https://beee.azurewebsites.net/rest/service/getUserData?") else { return }
         
        
         do {
             let httpBody = try? JSONSerialization.data(withJSONObject: pram, options: [])
        
             var request = URLRequest(url: url as URL)
             request.httpMethod = "POST"
             request.httpBody = httpBody
             request.setValue(" application/json", forHTTPHeaderField:"Content-Type")
             request.addValue("application/json", forHTTPHeaderField: "Accept")
        
         //
         
             let session = URLSession.shared
                 session.dataTask(with: request) { (data, response, error) in
             
                         if error != nil {
                             
         // display an alert if there is an error inside the DispatchQueue.main.async

                             DispatchQueue.main.async
                             {
                                     let alert = UIAlertController(title: "can't complete the request", message: "Do you have Internet access?", preferredStyle: .alert)
                                     alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                     self.present(alert, animated: true, completion: nil)
                             }
                         }
                         else
                         {
                            if let unwrappedData = data {
                                 
                                 let returnedData = NSString(data: unwrappedData, encoding: String.Encoding.utf8.rawValue) // Response from web server hosting the database
                                print(String(returnedData!))
                                 if returnedData != "" // insert into database worked
                                 {

         // display an alert if no error and database insert worked (return = 1) inside the DispatchQueue.main.async
                                    if returnedData == "false"
                                    {
                                        let alert = UIAlertController(title: "Sorry", message: "Permit was rejected", preferredStyle: .alert)
                                                                                                 alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                                                                                 self.present(alert, animated: true, completion: nil)
                                    }
                                    
                                    else
                                    {
                                       
                                        let data1 = returnedData
                                            let filter = CIFilter(name: "CIQRCodeGenerator")
                                            filter?.setValue(data1 , forKey:"InputMessage")
                                            
                                            let ciImage = filter?.outputImage
                                            
                                            let transform = CGAffineTransform(scaleX: 10, y: 10)
                                            let transformImage = ciImage?.transformed(by: transform)
                                            
                                            
                                            let image = UIImage( ciImage: transformImage!)
                                        self.qrImageView.image=image
                                            
                                        self.saveButton.isEnabled=true;

                                    }
                                    
                                    // recevid data = returndata

                                   
                                 }
                                 else
                                 {
         // display an alert if an error and database insert didn't worked (return != 1) inside the DispatchQueue.main.async

                                     DispatchQueue.main.async
                                     {

                                     let alert = UIAlertController(title: "Wait", message: "Your request is under process , please try again later", preferredStyle: .alert)
                                     alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                     self.present(alert, animated: true, completion: nil)
                                     }
                                 }
                             }
                 }
             }.resume()
                     
                 }
             
    
        
        
        
        // qr code generatting
        
                    
       
        
    }
    
   
    @IBAction func saveButton(_ sender: Any) {
        
        saveImage()
    }
    
    func saveImage()
    {
        let layer = UIApplication.shared.keyWindow!.layer
        let scale = UIScreen.main.scale
        UIGraphicsBeginImageContextWithOptions(layer.frame.size, false, scale)
        
        layer.render(in: UIGraphicsGetCurrentContext()!)
        
        let screenshot = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        UIImageWriteToSavedPhotosAlbum(screenshot!,nil,nil,nil)
    }
    
    
    @IBAction func backPressed(_ sender: Any) {
        
         dismiss(animated: true, completion: nil)    }
    
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


