//
//  ViewController.swift
//  MyPermission
//
//  Created by ArwaA on 27/08/1441 AH.
//  Copyright © 1441 ArwaA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nationID: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    var loggedID:String!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var loginB: UIButton!
    
    @IBAction func loginPressed(_ sender: Any) {
        
        //send id
        
            let id: String
            id = nationID.text!
            
            let pass: String
            pass = password.text!
            
            if(!id.isEmpty  && !pass.isEmpty)
            {
                //send id
                if(id.count != 10)
                {
                    let action = UIAlertController (title: "Wrong Data", message: "National ID must be 10 digits!", preferredStyle: .alert)
                                  action.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    
                     self.present(action, animated: true, completion: nil)
                }
                else
                {
                performSegue(withIdentifier: "toSecond", sender: self)
                }
            }
            else
            {
                let alert = UIAlertController(title: "Error!", message: "Please fill empty fields", preferredStyle: UIAlertController.Style.alert)
                
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let nextViewController = segue.destination as! HomeController
        nextViewController.loggedID = nationID.text!
        
    }
}

